const toggle = document.querySelector('.toggle');
    const navig = document.querySelector('.navig');
    toggle.onclick = function () {
        toggle.classList.toggle('active');
        navig.classList.toggle('active');
    }

    const slider_item = document.querySelectorAll('.slider_item');
    const dots = document.querySelectorAll('.dot');

    function setActive(i) {

        for (slider of slider_item)
            slider.classList.remove('activee');
        slider_item[i].classList.add('activee');

        for (dot of dots)
            dot.classList.remove('active');
        dots[i].classList.add('active');
    }
    for (let i = 0; i < dots.length; i++) {
        dots[i].addEventListener('click', function () {
            setActive(i)
        })
    }
