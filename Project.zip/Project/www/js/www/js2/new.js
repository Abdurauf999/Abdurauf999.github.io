let x = 10
let y = 20
console.log(x + y)
